package com.example.demo.service;

import java.util.List;

import com.example.demo.data.Account;

//import com.microapi.apifirst.data.Account;

public interface AccService {
	
	public List <Account> getDetails();

	public Account getDetail(int acc);

	public Account getDetail1(String acctype);

	public Account createAcc(Account acc);
	public Account updateAcc(Account ac);

	public void delAccount(int accDel);


}
