package com.example.demo.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.data.Account;
import com.example.demo.service.AccService;


@RestController
public class ProjControl {//control class
	@Autowired
	private AccService accservice;
	

	@GetMapping("/getdetails")
	public List<Account> getDetails() {
		
		return this.accservice.getDetails();
		/*try {
			List<Account> acc= this.accservice.getDetails();
			return new ResponseEntity<>(acc, HttpStatus.OK);
		}
		catch(Exception e) {
             System.out.println("Executing get query");
	
			
			return new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
		}*/
		
	}
	@PostMapping(path="/getdetails", consumes="application/json")
	public Account createAcc(@RequestBody Account acc) {
		return this.accservice.createAcc(acc);
	}
	
	
	
	@GetMapping("/getdetails/{accNo}")
	public Account getAcc(@PathVariable String accNo) {
		//by default we get string typ so convert into long
		return this.accservice.getDetail(Integer.parseInt(accNo));
		
		/*try {
			Account ac= this.accservice.getDetail(Long.parseLong(acc));
			return new ResponseEntity<>(ac, HttpStatus.OK);
		}
		catch(Exception e) {
             System.out.println("Executing get query");
			return new ResponseEntity<>(HttpStatus.BAD_GATEWAY);
		}*/
		
	}
	@DeleteMapping(path="/deleteAccount/{acc}", consumes="application/json")
	public void delAccount(@PathVariable String acc) {
		this.accservice.delAccount(Integer.parseInt(acc));
		
	}
	@PutMapping(path="/updateacc", consumes="application/json")
	public Account updateAcc(@RequestBody Account acc) {
		return this.accservice.updateAcc(acc);
	}
	

}
