package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.acDao;
import com.example.demo.data.Account;


@Service
public class AccClass implements AccService{
	
	@Autowired
	private acDao acdao;

	@Override
	public List<Account> getDetails() {
		// TODO Auto-generated method stub
		return acdao.findAll();
	}



	@Override
	public Account getDetail(int acc) {
		// TODO Auto-generated method stub
		Account a=acdao.getOne(acc);
		return a;
	}

	@Override
	public Account getDetail1(String acctype) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account createAcc(Account acc) {
		// TODO Auto-generated method stub
		acdao.save(acc);
		return acc;
	}

	@Override
	public Account updateAcc(Account ac) {
		// TODO Auto-generated method stub
		acdao.save(ac);
		return ac;
	}

	@Override
	public void delAccount(int accDel) {
		// TODO Auto-generated method stub
		Account acnt=acdao.getOne(accDel);
		acdao.delete(acnt);
		//return acnt;
	}

	
	
	
	

}
