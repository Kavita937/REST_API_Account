package com.example.demo.data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
//import javax.persistence.Table;
import javax.persistence.Table;

@Entity
//@Table(name="account")
public class Account {
	@Column(name="accType")
	private String accType;
	@Id
	@Column(name="accNo")
	private int accNo;
	@Column(name="custName")
	private String custName;
	@Column(name="custGender")
	private String custGender;
	@Column(name="accBal")
	private double accBal;
	
	public Account() {
		
	}
	
	public Account(String accType, int accNo, String custName, String custGender, double accBal) {
		this.accType = accType;
		this.accNo = accNo;
		this.custName = custName;
		this.custGender = custGender;
		this.accBal = accBal;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustGender() {
		return custGender;
	}
	public void setCustGender(String custGender) {
		this.custGender = custGender;
	}
	public double getAccBal() {
		return accBal;
	}
	public void setAccBal(double accBal) {
		this.accBal = accBal;
	}
	@Override
	public String toString() {
		return "Account [accType=" + accType + ", accNo=" + accNo + ", custName=" + custName + ", custGender="
				+ custGender + ", accBal=" + accBal + "]";
	}
	
	
	

}
